//
//  ViewController.swift
//  Iffy_singleview
//
//  Created by YeongSoo Kim on 18/04/2019.
//  Copyright © 2019 YeongSoo Kim. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

